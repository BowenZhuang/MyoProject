var searchData=
[
  ['fromaxisangle',['fromAxisAngle',['../classmyo_1_1_quaternion.html#af4397481d462d3480b45708f38c1db77',1,'myo::Quaternion']]]
];
