var searchData=
[
  ['vector3',['Vector3',['../classmyo_1_1_vector3.html#acef217cae23a09ea947d575584a7a383',1,'myo::Vector3::Vector3()'],['../classmyo_1_1_vector3.html#a98336d1d2a21fc6fb656f63db8db5b5b',1,'myo::Vector3::Vector3(T x, T y, T z)'],['../classmyo_1_1_vector3.html#a295ca3ce8d42752c6d92482942692926',1,'myo::Vector3::Vector3(const Vector3 &amp;other)']]],
  ['vibrate',['vibrate',['../classmyo_1_1_myo.html#a5364a3d446c8d60fdc381b0bb2cb6c92',1,'myo::Myo']]]
];
