var examples =
[
    [ "emg-data-sample.cpp", "emg-data-sample_8cpp-example.html", null ],
    [ "hello-myo.cpp", "hello-myo_8cpp-example.html", null ],
    [ "multiple-myos.cpp", "multiple-myos_8cpp-example.html", null ]
];