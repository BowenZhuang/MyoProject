var searchData=
[
  ['quaternion',['Quaternion',['../classmyo_1_1_quaternion.html',1,'myo']]],
  ['quaternion',['Quaternion',['../classmyo_1_1_quaternion.html#a5429d1748c7a73f804d9e3b80b90f81a',1,'myo::Quaternion::Quaternion()'],['../classmyo_1_1_quaternion.html#a501baac47aa2e0dc1d27bc372e2c1af9',1,'myo::Quaternion::Quaternion(T x, T y, T z, T w)']]]
];
